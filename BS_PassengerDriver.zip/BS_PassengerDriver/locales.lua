Locales = {}

Locales["en-GB"] = { -- Do NOT adjust any character after a %, nor any character after a \
  TookControl = "The trainer took control of the vehicle",
  ReleasedControl = "The trainer released control back to you",
}

Locales["en-US"] = {
  TookControl = "The trainer took control of the vehicle",
  ReleasedControl = "The trainer released control back to you",
}

Locales["fr"] = {
  TookControl = "The trainer took control of the vehicle",
  ReleasedControl = "The trainer released control back to you",
}